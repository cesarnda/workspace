package edu.harvard.cscie124.pa3;

import java.util.List;

public class NumberPartitionExponentialApproach implements
		NumberPartitionSolver {

	@Override
	public long getResidue(List<Long> list) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
