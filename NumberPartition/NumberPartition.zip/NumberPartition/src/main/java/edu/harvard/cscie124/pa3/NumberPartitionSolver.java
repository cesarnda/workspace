package edu.harvard.cscie124.pa3;

import java.util.List;

public interface NumberPartitionSolver {

	public long getResidue(List<Long> list);
	
}
