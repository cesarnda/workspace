package edu.harvard.cscie124.pa3;

import org.junit.Test;

public class PrintResultsForLatex extends AbstractTestCases {

	@Test
	public void printResolts(){
		printSolutionsForLatex();
	}
}
